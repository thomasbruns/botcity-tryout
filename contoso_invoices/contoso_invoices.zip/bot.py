from botcity.core import DesktopBot


def not_found(label):

    print(f"Element not found: {label}")


def invoice_registration():

    test_date = '08/06/2023'
    test_account = '123456'
    test_email = 'thomas.fritsfb@gmail.com'
    test_amount = '1000'

    bot = DesktopBot()

    contoso_invoices_path = "C:\Program Files (x86)\Contoso, Inc\Contoso Invoicing\LegacyInvoicingApp.exe"

    bot.execute(contoso_invoices_path)
    bot.wait(2000)
    bot.maximize_window()

    if not bot.find( "invoices", matching=0.97, waiting_time=10000):
        not_found("invoices")
    bot.click()

    if not bot.find( "new_entry", matching=0.97, waiting_time=10000):
        not_found("new_entry")
    bot.click()
    
    if not bot.find( "date", matching=0.97, waiting_time=10000):
        not_found("date")
    bot.click_relative(87, 13)

    bot.type_keys(['home'])
    bot.type_keys(['shift', 'end'])

    bot.paste(test_date)
    bot.tab()

    # go to account
    bot.paste(test_account)
    bot.tab()

    # go to contact
    bot.paste(test_email)
    bot.tab()
    
    # go to amount
    bot.paste(test_amount)
    
    if not bot.find( "status", matching=0.97, waiting_time=10000):
        not_found("status")
    bot.click_relative(88, 15)
    
    if not bot.find( "status_uninvoiced", matching=0.97, waiting_time=10000):
        not_found("status_uninvoiced")
    bot.click_relative(91, 43)
    
    
    


if __name__ == '__main__':
    invoice_registration()

