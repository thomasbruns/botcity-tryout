#!/bin/bash

zip -r "contoso_invoices.zip" * -x "contoso_invoices.zip"